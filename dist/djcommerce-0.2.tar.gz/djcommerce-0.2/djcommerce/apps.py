from django.apps import AppConfig


class DjcommerceConfig(AppConfig):
    name = 'djcommerce'
