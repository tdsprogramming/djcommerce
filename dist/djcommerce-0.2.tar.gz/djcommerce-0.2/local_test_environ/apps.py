from django.apps import AppConfig


class LocalTestEnvironConfig(AppConfig):
    name = 'local_test_environ'
