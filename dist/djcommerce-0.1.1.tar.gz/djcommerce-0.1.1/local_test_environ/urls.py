from django.urls import path


urlpatterns = [
    # path('address/create/', AddressCreateView.as_view())
]
