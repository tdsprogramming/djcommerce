from djcommerce.models.order import Order
from djcommerce.models.address import Address

class CustomOrder(Order):
    pass

class CustomAddress(Address):
    pass
